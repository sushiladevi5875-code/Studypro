# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# ProGuard / R8 rules for StudyPro Release APK
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Keep Firebase data model classes to prevent minification breaks on Firestore serialization
-keepclassmembers class com.example.data.model.** {
    <fields>;
    <init>(...);
}
-keep class com.example.data.model.** { *; }

# Keep Credential Manager & Google Sign-In classes
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
