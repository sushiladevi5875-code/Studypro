package com.example

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.repository.StudyProRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class StudyProRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createSubject_authenticatedUser_createsAndReturnsId() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = StudyProRepository(firestore, auth)

        val subjectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addSubject("Calculus", "#2563EB", 50L)
        }
        assertTrue(subjectId.isNotEmpty())

        val subjects = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSubjects(uid).first { list -> list.any { it.id == subjectId } }
        }
        assertTrue(subjects.any { it.id == subjectId })
    }

    @Test
    fun crossUserAccess_bobCannotAccessAliceSubcollection_denied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = StudyProRepository(firestore, auth)
        val subjectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.addSubject("Physics", "#7C3AED", 40L)
        }
        assertTrue(subjectId.isNotEmpty())

        signInTestUser(BOB_EMAIL)
        val bobRepo = StudyProRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeSubjects(aliceUid).first()
            }
            fail("Expected exception when Bob queries Alice's subjects")
        } catch (e: Exception) {
            val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
        }
    }

    @Test
    fun unauthenticatedAccess_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = StudyProRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeSubjects("some_uid").first()
            }
            fail("Expected exception for unauthenticated observer")
        } catch (e: Exception) {
            val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
                "Expected nested FirebaseFirestoreException, got $e"
            }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_student@test.com"
        const val BOB_EMAIL = "bob_student@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
