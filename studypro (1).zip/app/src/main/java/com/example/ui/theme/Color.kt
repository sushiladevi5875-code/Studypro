package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// StudyPro Brand Colors
val NavyBackground = Color(0xFF0B132B)
val NavySurface = Color(0xFF121B3B)
val NavyCard = Color(0xFF18244B)
val NavyCardElevated = Color(0xFF202E5C)
val NavyBorder = Color(0xFF283A70)

val ElectricBlue = Color(0xFF2563EB)
val ElectricBlueLight = Color(0xFF38BDF8)
val ElectricBlueGlow = Color(0xFF00D2FF)

val RoyalPurple = Color(0xFF7C3AED)
val RoyalPurpleLight = Color(0xFFA78BFA)
val PurpleDark = Color(0xFF5B21B6)

val GoldAccent = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFBBF24)
val GoldSoft = Color(0xFFFEF3C7)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Light Theme equivalents
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF97316)
