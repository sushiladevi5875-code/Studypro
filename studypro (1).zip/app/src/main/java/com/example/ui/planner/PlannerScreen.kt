package com.example.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudyGoal
import com.example.ui.StudyProUiState
import com.example.ui.StudyProViewModel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningOrange
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PlannerFilter(val title: String) {
    TODAY("Today"),
    TOMORROW("Tomorrow"),
    UPCOMING("Upcoming"),
    COMPLETED("Completed"),
    ALL("All")
}

@Composable
fun PlannerScreen(
    uiState: StudyProUiState,
    viewModel: StudyProViewModel
) {
    var selectedFilter by remember { mutableStateOf(PlannerFilter.TODAY) }
    var showAddGoalDialog by remember { mutableStateOf(false) }

    val todayCal = Calendar.getInstance()
    val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(todayCal.time)
    todayCal.add(Calendar.DAY_OF_YEAR, 1)
    val tomorrowIso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(todayCal.time)

    val filteredGoals = when (selectedFilter) {
        PlannerFilter.TODAY -> uiState.goals.filter { it.targetDate == todayIso && !it.isCompleted }
        PlannerFilter.TOMORROW -> uiState.goals.filter { it.targetDate == tomorrowIso && !it.isCompleted }
        PlannerFilter.UPCOMING -> uiState.goals.filter { it.targetDate > todayIso && !it.isCompleted }
        PlannerFilter.COMPLETED -> uiState.goals.filter { it.isCompleted }
        PlannerFilter.ALL -> uiState.goals
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddGoalDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_goal_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Goal")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Study Planner",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Organize goals, assign chapters, and execute daily routines.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Filter Chips Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(PlannerFilter.values()) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.title) },
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredGoals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No study goals for ${selectedFilter.title}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the + button to schedule your next study session.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredGoals) { goal ->
                        GoalCard(
                            goal = goal,
                            onToggle = { viewModel.toggleGoal(goal) },
                            onDelete = { viewModel.deleteGoal(goal.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }

    if (showAddGoalDialog) {
        AddStudyGoalDialog(
            uiState = uiState,
            defaultDate = todayIso,
            onDismiss = { showAddGoalDialog = false },
            onConfirm = { subjectId, subjectName, chapterId, chapterTitle, date, time, duration, priority, notes ->
                viewModel.addGoal(
                    subjectId = subjectId,
                    subjectName = subjectName,
                    chapterId = chapterId,
                    chapterTitle = chapterTitle,
                    targetDate = date,
                    targetTime = time,
                    durationMinutes = duration,
                    priority = priority,
                    notes = notes
                )
                showAddGoalDialog = false
            }
        )
    }
}

@Composable
private fun GoalCard(
    goal: StudyGoal,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val priorityColor = when (goal.priority.lowercase()) {
        "high" -> ErrorRed
        "medium" -> WarningOrange
        else -> ElectricBlue
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("goal_card_${goal.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.CheckCircle,
                    contentDescription = if (goal.isCompleted) "Completed" else "Pending",
                    tint = if (goal.isCompleted) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = priorityColor.copy(alpha = 0.15f),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = goal.priority.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = priorityColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Text(
                        text = goal.subjectName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = goal.chapterTitle ?: "${goal.durationMinutes} min Study Session",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (goal.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (goal.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )

                if (!goal.notes.isNullOrBlank()) {
                    Text(
                        text = goal.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = goal.targetDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${goal.durationMinutes} mins ${if (!goal.targetTime.isNullOrBlank()) "@ ${goal.targetTime}" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Outlined.Delete,
                    contentDescription = "Delete Goal",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddStudyGoalDialog(
    uiState: StudyProUiState,
    defaultDate: String,
    onDismiss: () -> Unit,
    onConfirm: (
        subjectId: String,
        subjectName: String,
        chapterId: String?,
        chapterTitle: String?,
        date: String,
        time: String?,
        duration: Long,
        priority: String,
        notes: String?
    ) -> Unit
) {
    val defaultSub = uiState.subjects.firstOrNull()
    var selectedSubject by remember { mutableStateOf(defaultSub) }
    var selectedChapter by remember { mutableStateOf<com.example.data.model.Chapter?>(null) }
    var targetDate by remember { mutableStateOf(defaultDate) }
    var targetTime by remember { mutableStateOf("17:00") }
    var durationMinutesStr by remember { mutableStateOf("45") }
    var priority by remember { mutableStateOf("medium") }
    var notes by remember { mutableStateOf("") }

    var subjectExpanded by remember { mutableStateOf(false) }
    var chapterExpanded by remember { mutableStateOf(false) }

    val chaptersForSubject = uiState.chapters.filter { it.subjectId == selectedSubject?.id }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule Study Goal", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Subject Dropdown
                ExposedDropdownMenuBox(
                    expanded = subjectExpanded,
                    onExpandedChange = { subjectExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedSubject?.name ?: "Select Subject",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        label = { Text("Subject") }
                    )
                    ExposedDropdownMenu(
                        expanded = subjectExpanded,
                        onDismissRequest = { subjectExpanded = false }
                    ) {
                        uiState.subjects.forEach { sub ->
                            DropdownMenuItem(
                                text = { Text(sub.name) },
                                onClick = {
                                    selectedSubject = sub
                                    selectedChapter = null
                                    subjectExpanded = false
                                }
                            )
                        }
                    }
                }

                // Chapter Dropdown (optional)
                if (chaptersForSubject.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = chapterExpanded,
                        onExpandedChange = { chapterExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedChapter?.title ?: "Select Chapter (Optional)",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = chapterExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            label = { Text("Chapter") }
                        )
                        ExposedDropdownMenu(
                            expanded = chapterExpanded,
                            onDismissRequest = { chapterExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (General Study)") },
                                onClick = {
                                    selectedChapter = null
                                    chapterExpanded = false
                                }
                            )
                            chaptersForSubject.forEach { ch ->
                                DropdownMenuItem(
                                    text = { Text(ch.title) },
                                    onClick = {
                                        selectedChapter = ch
                                        chapterExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = targetDate,
                        onValueChange = { targetDate = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1.3f)
                    )
                    OutlinedTextField(
                        value = targetTime,
                        onValueChange = { targetTime = it },
                        label = { Text("Time (HH:mm)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = durationMinutesStr,
                        onValueChange = { durationMinutesStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Duration (mins)") },
                        modifier = Modifier.weight(1f)
                    )

                    // Priority Buttons
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Priority", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("low", "medium", "high").forEach { p ->
                                val isSelected = priority == p
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) ElectricBlue else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .clickable { priority = p }
                                        .weight(1f)
                                        .height(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = p.take(1).uppercase(),
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Goal Notes (Optional)") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sub = selectedSubject
                    if (sub != null && targetDate.isNotBlank()) {
                        val duration = durationMinutesStr.toLongOrNull() ?: 45L
                        onConfirm(
                            sub.id,
                            sub.name,
                            selectedChapter?.id,
                            selectedChapter?.title,
                            targetDate.trim(),
                            targetTime.ifBlank { null },
                            duration,
                            priority,
                            notes.ifBlank { null }
                        )
                    }
                },
                enabled = selectedSubject != null && targetDate.isNotBlank()
            ) {
                Text("Schedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
