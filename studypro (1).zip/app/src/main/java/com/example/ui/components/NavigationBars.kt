package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.AppScreen
import com.example.ui.StudyProUiState
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavySurface
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.WarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyProTopBar(
    uiState: StudyProUiState,
    onNavigate: (AppScreen) -> Unit
) {
    TopAppBar(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(ElectricBlue, RoyalPurple)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.studypro_logo_1794011477346),
                        contentDescription = "StudyPro Logo",
                        modifier = Modifier.size(30.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "STUDYPRO",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        },
        actions = {
            // Streak Pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = WarningOrange.copy(alpha = 0.15f),
                modifier = Modifier.padding(end = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Streak",
                        tint = WarningOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${uiState.userProfile.streakCount}d",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarningOrange
                    )
                }
            }

            // XP / Gamification Pill
            IconButton(
                onClick = { onNavigate(AppScreen.GAMIFICATION) },
                modifier = Modifier.testTag("gamification_top_button")
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = GoldAccent.copy(alpha = 0.15f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "XP",
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${uiState.userProfile.xp}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent
                        )
                    }
                }
            }

            // Pro / Upgrade Button
            IconButton(
                onClick = { onNavigate(AppScreen.PREMIUM) },
                modifier = Modifier.testTag("premium_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Premium",
                    tint = if (uiState.userProfile.isPremium) GoldAccent else MaterialTheme.colorScheme.primary
                )
            }

            // Admin panel access (shown for verified admin)
            if (uiState.isAdmin) {
                IconButton(
                    onClick = { onNavigate(AppScreen.ADMIN) },
                    modifier = Modifier.testTag("admin_top_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin Panel",
                        tint = RoyalPurple
                    )
                }
            }

            // Settings Button
            IconButton(
                onClick = { onNavigate(AppScreen.SETTINGS) },
                modifier = Modifier.testTag("settings_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

@Composable
fun StudyProBottomBar(
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        NavigationBarItem(
            selected = currentScreen == AppScreen.DASHBOARD,
            onClick = { onNavigate(AppScreen.DASHBOARD) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.DASHBOARD) Icons.Default.Dashboard else Icons.Outlined.Dashboard,
                    contentDescription = "Dashboard"
                )
            },
            label = { Text("Home") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ElectricBlue.copy(alpha = 0.2f),
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue
            ),
            modifier = Modifier.testTag("tab_dashboard")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.SUBJECTS,
            onClick = { onNavigate(AppScreen.SUBJECTS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.SUBJECTS) Icons.Default.MenuBook else Icons.Outlined.MenuBook,
                    contentDescription = "Subjects"
                )
            },
            label = { Text("Subjects") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = RoyalPurple.copy(alpha = 0.2f),
                selectedIconColor = RoyalPurple,
                selectedTextColor = RoyalPurple
            ),
            modifier = Modifier.testTag("tab_subjects")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.PLANNER,
            onClick = { onNavigate(AppScreen.PLANNER) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.PLANNER) Icons.Default.CalendarMonth else Icons.Outlined.CalendarMonth,
                    contentDescription = "Planner"
                )
            },
            label = { Text("Planner") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ElectricBlue.copy(alpha = 0.2f),
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue
            ),
            modifier = Modifier.testTag("tab_planner")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.TIMER,
            onClick = { onNavigate(AppScreen.TIMER) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.TIMER) Icons.Default.Timer else Icons.Outlined.Timer,
                    contentDescription = "Timer"
                )
            },
            label = { Text("Timer") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = GoldAccent.copy(alpha = 0.2f),
                selectedIconColor = GoldAccent,
                selectedTextColor = GoldAccent
            ),
            modifier = Modifier.testTag("tab_timer")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.ANALYTICS,
            onClick = { onNavigate(AppScreen.ANALYTICS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.ANALYTICS) Icons.Default.BarChart else Icons.Outlined.BarChart,
                    contentDescription = "Analytics"
                )
            },
            label = { Text("Analytics") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ElectricBlue.copy(alpha = 0.2f),
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue
            ),
            modifier = Modifier.testTag("tab_analytics")
        )
    }
}
