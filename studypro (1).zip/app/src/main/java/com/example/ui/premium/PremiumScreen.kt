package com.example.ui.premium

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.StudyProUiState
import com.example.ui.StudyProViewModel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyCardElevated
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.SuccessGreen

enum class SubscriptionPlanTier(val id: String, val title: String, val defaultPrice: String, val duration: String, val saveLabel: String?) {
    MONTHLY("pro_monthly", "Monthly Plan", "₹49", "per month", null),
    YEARLY("pro_yearly", "Annual Plan", "₹399", "per year", "SAVE 32%")
}

@Composable
fun PremiumScreen(
    uiState: StudyProUiState,
    viewModel: StudyProViewModel
) {
    val context = LocalContext.current
    var selectedPlan by remember { mutableStateOf(SubscriptionPlanTier.YEARLY) }
    var showUtrDialog by remember { mutableStateOf(false) }
    var utrInput by remember { mutableStateOf("") }

    val paymentConfig = uiState.paymentConfig
    val activePrice = if (selectedPlan == SubscriptionPlanTier.MONTHLY) paymentConfig.monthlyPrice else paymentConfig.yearlyPrice
    val numericAmount = activePrice.replace("₹", "").trim()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(GoldAccent, RoyalPurple)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "StudyPro Pro",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "StudyPro Premium",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Supercharge your academic performance with professional productivity tools and direct Google Pay activation.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }

        // Current Subscription Status Badge
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (uiState.userProfile.isPremium) SuccessGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Current Status",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (uiState.userProfile.isPremium) "STUDYPRO PRO ACTIVE" else "FREE TIER",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.userProfile.isPremium) SuccessGreen else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (uiState.userProfile.isPremium) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreen
                        ) {
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Pricing Cards (Monthly vs Yearly)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SubscriptionPlanTier.values().forEach { plan ->
                    val isSelected = selectedPlan == plan
                    val displayedPrice = if (plan == SubscriptionPlanTier.MONTHLY) paymentConfig.monthlyPrice else paymentConfig.yearlyPrice

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPlan = plan }
                            .then(
                                if (isSelected) Modifier.border(2.dp, GoldAccent, RoundedCornerShape(18.dp))
                                else Modifier
                            ),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) NavyCardElevated else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (plan.saveLabel != null) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = GoldAccent
                                ) {
                                    Text(
                                        text = plan.saveLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.height(18.dp))
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = plan.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = displayedPrice,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = plan.duration,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Direct Google Pay / UPI Details Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = NavyCardElevated
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Direct Google Pay / UPI Transfer",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Pay directly to our verified bank account via Google Pay, PhonePe, Paytm, or any UPI app. 0% extra fee.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Payee: ${paymentConfig.payeeName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = paymentConfig.upiId,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricBlue
                                )
                            }

                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("UPI ID", paymentConfig.upiId)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "UPI ID copied to clipboard!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy UPI ID",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Feature Comparison Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Plan Comparison",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ComparisonRow("Subject & Chapter Tracker", free = true, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Pomodoro Study Timer", free = true, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Daily Study Planner", free = true, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Study Streaks & Achievements", free = true, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Publication PDF Reports", free = false, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Cloud Backup & Sync", free = false, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Advanced Subject Analytics", free = false, pro = true)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 6.dp))
                    ComparisonRow("Premium Custom Themes", free = false, pro = true)
                }
            }
        }

        // Action Buttons: Pay via Google Pay / UPI & Submit UTR
        item {
            Button(
                onClick = {
                    if (uiState.isGuestMode) {
                        Toast.makeText(context, "Please sign in with Google to purchase Pro.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val upiUri = Uri.parse(
                        "upi://pay?pa=${paymentConfig.upiId}&pn=${Uri.encode(paymentConfig.payeeName)}&am=$numericAmount&cu=INR&tn=${Uri.encode("StudyPro ${selectedPlan.title}")}"
                    )
                    val intent = Intent(Intent.ACTION_VIEW, upiUri)
                    try {
                        context.startActivity(Intent.createChooser(intent, "Pay via Google Pay or UPI"))
                    } catch (e: Exception) {
                        Toast.makeText(
                            context,
                            "No UPI app detected. Please copy the UPI ID above and pay via Google Pay manually.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("pay_gpay_upi_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Pay $activePrice with Google Pay / UPI",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = {
                    if (uiState.isGuestMode) {
                        Toast.makeText(context, "Please sign in with Google first.", Toast.LENGTH_SHORT).show()
                    } else {
                        showUtrDialog = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_utr_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Already Paid? Submit 12-digit UTR",
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Direct payments reach the owner's bank account instantly. Pro is verified and activated by Admin upon UTR receipt. Your study data is always preserved.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Submit 12-digit UTR Transaction Modal
    if (showUtrDialog) {
        AlertDialog(
            onDismissRequest = { showUtrDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = SuccessGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Submit Payment UTR")
                }
            },
            text = {
                Column {
                    Text(
                        text = "Enter the 12-digit UPI / Google Pay Transaction Ref (UTR) from your payment receipt:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = utrInput,
                        onValueChange = { utrInput = it },
                        label = { Text("12-digit UTR Number") },
                        placeholder = { Text("e.g. 403819284719") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Plan: ${selectedPlan.title} ($activePrice)",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (utrInput.trim().length >= 6) {
                            viewModel.submitPaymentUtr(
                                planId = selectedPlan.id,
                                amount = activePrice,
                                utrNumber = utrInput.trim()
                            ) {
                                showUtrDialog = false
                                utrInput = ""
                            }
                        } else {
                            Toast.makeText(context, "Please enter a valid UTR number.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                ) {
                    Text("Submit for Approval")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUtrDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ComparisonRow(feature: String, free: Boolean, pro: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = feature,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )

        Row(
            modifier = Modifier.width(120.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            if (free) {
                Icon(Icons.Default.Check, contentDescription = "Included in Free", tint = SuccessGreen, modifier = Modifier.size(18.dp))
            } else {
                Icon(Icons.Default.Close, contentDescription = "Not in Free", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
            }

            if (pro) {
                Icon(Icons.Default.Check, contentDescription = "Included in Pro", tint = GoldAccent, modifier = Modifier.size(18.dp))
            } else {
                Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }
    }
}
