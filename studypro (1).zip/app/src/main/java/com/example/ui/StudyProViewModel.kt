package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Achievement
import com.example.data.model.Announcement
import com.example.data.model.AppPaymentConfig
import com.example.data.model.Chapter
import com.example.data.model.PaymentRecord
import com.example.data.model.StudyGoal
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.data.model.SupportRequest
import com.example.data.model.UserProfile
import com.example.data.repository.StudyProRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class AppScreen {
    DASHBOARD,
    SUBJECTS,
    PLANNER,
    TIMER,
    ANALYTICS,
    GAMIFICATION,
    PREMIUM,
    ADMIN,
    SETTINGS
}

enum class TimerMode(val title: String, val defaultMinutes: Int) {
    POMODORO("Focus", 25),
    SHORT_BREAK("Short Break", 5),
    LONG_BREAK("Long Break", 15),
    STOPWATCH("Stopwatch", 0)
}

data class TimerState(
    val mode: TimerMode = TimerMode.POMODORO,
    val isRunning: Boolean = false,
    val remainingSeconds: Int = 25 * 60,
    val totalSeconds: Int = 25 * 60,
    val stopwatchSeconds: Int = 0,
    val selectedSubjectId: String? = null,
    val selectedSubjectName: String? = null,
    val selectedChapterId: String? = null,
    val selectedChapterTitle: String? = null,
    val completedSessionsCount: Int = 0
)

data class StudyProUiState(
    val currentScreen: AppScreen = AppScreen.DASHBOARD,
    val isGuestMode: Boolean = false,
    val userProfile: UserProfile = UserProfile(),
    val subjects: List<Subject> = emptyList(),
    val chapters: List<Chapter> = emptyList(),
    val goals: List<StudyGoal> = emptyList(),
    val sessions: List<StudySession> = emptyList(),
    val achievements: List<Achievement> = emptyList(),
    val announcements: List<Announcement> = emptyList(),
    val supportRequests: List<SupportRequest> = emptyList(),
    val paymentConfig: AppPaymentConfig = AppPaymentConfig(),
    val pendingPayments: List<PaymentRecord> = emptyList(),
    val timerState: TimerState = TimerState(),
    val isLoading: Boolean = false,
    val userMessage: String? = null,
    val isDarkTheme: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val isAdmin: Boolean = false
)

class StudyProViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StudyProRepository(application)
    private val auth: FirebaseAuth = Firebase.auth

    private val _uiState = MutableStateFlow(StudyProUiState())
    val uiState: StateFlow<StudyProUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var timerStartTimestamp: Long = 0L
    private var timerInitialRemainingMs: Long = 0L

    init {
        checkAdminStatus()
        observeData()
    }

    private fun checkAdminStatus() {
        val email = auth.currentUser?.email
        val isAdmin = email == "sushiladevi5875@gmail.com"
        _uiState.update { it.copy(isAdmin = isAdmin) }
    }

    fun setGuestMode(isGuest: Boolean) {
        _uiState.update {
            it.copy(
                isGuestMode = isGuest,
                userProfile = if (isGuest) {
                    UserProfile(
                        userId = "guest",
                        name = "Guest Scholar",
                        classGrade = "Self Learner",
                        dailyStudyTargetMinutes = 120L
                    )
                } else it.userProfile
            )
        }
        if (isGuest && _uiState.value.subjects.isEmpty()) {
            seedSampleGuestData()
        }
    }

    private fun seedSampleGuestData() {
        val defaultSubjects = listOf(
            Subject(id = "sub_math", userId = "guest", name = "Mathematics", colorHex = "#2563EB", targetHours = 60),
            Subject(id = "sub_phys", userId = "guest", name = "Physics", colorHex = "#7C3AED", targetHours = 50),
            Subject(id = "sub_chem", userId = "guest", name = "Chemistry", colorHex = "#10B981", targetHours = 45)
        )
        val defaultChapters = listOf(
            Chapter(id = "ch_1", userId = "guest", subjectId = "sub_math", title = "Calculus & Limits", orderIndex = 0, isCompleted = true),
            Chapter(id = "ch_2", userId = "guest", subjectId = "sub_math", title = "Linear Algebra", orderIndex = 1, isCompleted = false),
            Chapter(id = "ch_3", userId = "guest", subjectId = "sub_phys", title = "Thermodynamics", orderIndex = 0, isCompleted = false)
        )
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val defaultGoals = listOf(
            StudyGoal(
                id = "goal_1",
                userId = "guest",
                subjectId = "sub_math",
                subjectName = "Mathematics",
                chapterId = "ch_2",
                chapterTitle = "Linear Algebra",
                targetDate = todayStr,
                targetTime = "18:00",
                durationMinutes = 45,
                priority = "high",
                isCompleted = false
            )
        )
        _uiState.update {
            it.copy(
                subjects = defaultSubjects,
                chapters = defaultChapters,
                goals = defaultGoals
            )
        }
    }

    private fun observeData() {
        val uid = auth.currentUser?.uid ?: return
        checkAdminStatus()

        viewModelScope.launch {
            repository.observeUserProfile(uid).collectLatest { profile ->
                if (profile != null) {
                    _uiState.update { it.copy(userProfile = profile) }
                } else {
                    // Initialize new profile
                    val newProfile = UserProfile(
                        userId = uid,
                        name = auth.currentUser?.displayName ?: "Student Scholar",
                        classGrade = "Grade 11",
                        dailyStudyTargetMinutes = 120L
                    )
                    repository.saveUserProfile(newProfile)
                }
            }
        }

        viewModelScope.launch {
            repository.observeSubjects(uid).collectLatest { list ->
                _uiState.update { it.copy(subjects = list) }
            }
        }

        viewModelScope.launch {
            repository.observeChapters(uid).collectLatest { list ->
                _uiState.update { it.copy(chapters = list) }
            }
        }

        viewModelScope.launch {
            repository.observeGoals(uid).collectLatest { list ->
                _uiState.update { it.copy(goals = list) }
            }
        }

        viewModelScope.launch {
            repository.observeSessions(uid).collectLatest { list ->
                _uiState.update { it.copy(sessions = list) }
            }
        }

        viewModelScope.launch {
            repository.observeAchievements(uid).collectLatest { list ->
                _uiState.update { it.copy(achievements = list) }
            }
        }

        viewModelScope.launch {
            repository.observeAnnouncements().collectLatest { list ->
                _uiState.update { it.copy(announcements = list) }
            }
        }

        viewModelScope.launch {
            repository.observePaymentConfig().collectLatest { config ->
                _uiState.update { it.copy(paymentConfig = config) }
            }
        }

        if (_uiState.value.isAdmin) {
            viewModelScope.launch {
                repository.observePayments().collectLatest { payments ->
                    _uiState.update { it.copy(pendingPayments = payments) }
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun toggleNotifications() {
        _uiState.update { it.copy(notificationsEnabled = !it.notificationsEnabled) }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }

    fun updateUserProfile(name: String, classGrade: String, school: String?, dailyTargetMinutes: Long) {
        val current = _uiState.value.userProfile
        val updated = current.copy(
            name = name.trim(),
            classGrade = classGrade.trim(),
            school = school?.trim(),
            dailyStudyTargetMinutes = dailyTargetMinutes
        )
        if (_uiState.value.isGuestMode) {
            _uiState.update { it.copy(userProfile = updated, userMessage = "Profile updated locally!") }
            return
        }
        viewModelScope.launch {
            try {
                repository.saveUserProfile(updated)
                _uiState.update { it.copy(userMessage = "Profile saved!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to update profile: ${e.message}") }
            }
        }
    }

    // --- SUBJECTS ---
    fun addSubject(name: String, colorHex: String, targetHours: Long) {
        if (_uiState.value.isGuestMode) {
            val newSub = Subject(
                id = UUID.randomUUID().toString(),
                userId = "guest",
                name = name.trim(),
                colorHex = colorHex,
                targetHours = targetHours
            )
            _uiState.update { it.copy(subjects = it.subjects + newSub, userMessage = "Subject added!") }
            return
        }
        viewModelScope.launch {
            try {
                repository.addSubject(name, colorHex, targetHours)
                _uiState.update { it.copy(userMessage = "Subject created successfully!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to add subject: ${e.message}") }
            }
        }
    }

    fun updateSubject(subject: Subject) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(subjects = it.subjects.map { s -> if (s.id == subject.id) subject else s })
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.updateSubject(subject)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to update: ${e.message}") }
            }
        }
    }

    fun deleteSubject(subjectId: String) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(
                    subjects = it.subjects.filterNot { s -> s.id == subjectId },
                    chapters = it.chapters.filterNot { c -> c.subjectId == subjectId }
                )
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteSubject(subjectId)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to delete subject: ${e.message}") }
            }
        }
    }

    // --- CHAPTERS ---
    fun addChapter(subjectId: String, title: String, notes: String?) {
        if (_uiState.value.isGuestMode) {
            val newCh = Chapter(
                id = UUID.randomUUID().toString(),
                userId = "guest",
                subjectId = subjectId,
                title = title.trim(),
                orderIndex = _uiState.value.chapters.count { it.subjectId == subjectId }.toLong(),
                notes = notes
            )
            _uiState.update { it.copy(chapters = it.chapters + newCh, userMessage = "Chapter added!") }
            return
        }
        viewModelScope.launch {
            try {
                repository.addChapter(subjectId, title, 0L, notes)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to add chapter: ${e.message}") }
            }
        }
    }

    fun toggleChapter(chapter: Chapter) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(chapters = it.chapters.map { c ->
                    if (c.id == chapter.id) c.copy(isCompleted = !c.isCompleted) else c
                })
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.toggleChapterCompletion(chapter)
                checkChapterAchievements()
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to update chapter: ${e.message}") }
            }
        }
    }

    fun deleteChapter(chapterId: String) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(chapters = it.chapters.filterNot { c -> c.id == chapterId })
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteChapter(chapterId)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to delete: ${e.message}") }
            }
        }
    }

    // --- GOALS / PLANNER ---
    fun addGoal(
        subjectId: String,
        subjectName: String,
        chapterId: String?,
        chapterTitle: String?,
        targetDate: String,
        targetTime: String?,
        durationMinutes: Long,
        priority: String,
        notes: String?
    ) {
        if (_uiState.value.isGuestMode) {
            val newGoal = StudyGoal(
                id = UUID.randomUUID().toString(),
                userId = "guest",
                subjectId = subjectId,
                subjectName = subjectName,
                chapterId = chapterId,
                chapterTitle = chapterTitle,
                targetDate = targetDate,
                targetTime = targetTime,
                durationMinutes = durationMinutes,
                priority = priority,
                notes = notes
            )
            _uiState.update { it.copy(goals = it.goals + newGoal, userMessage = "Study goal added!") }
            return
        }
        viewModelScope.launch {
            try {
                repository.addGoal(
                    subjectId,
                    subjectName,
                    chapterId,
                    chapterTitle,
                    targetDate,
                    targetTime,
                    durationMinutes,
                    priority,
                    notes
                )
                _uiState.update { it.copy(userMessage = "Study goal scheduled!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to schedule goal: ${e.message}") }
            }
        }
    }

    fun toggleGoal(goal: StudyGoal) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(goals = it.goals.map { g ->
                    if (g.id == goal.id) g.copy(isCompleted = !g.isCompleted) else g
                })
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.toggleGoalCompletion(goal)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to update goal: ${e.message}") }
            }
        }
    }

    fun deleteGoal(goalId: String) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(goals = it.goals.filterNot { g -> g.id == goalId })
            }
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteGoal(goalId)
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to delete goal: ${e.message}") }
            }
        }
    }

    // --- TIMER / POMODORO WITH ACCURATE TIME TRACKING ---
    fun selectTimerMode(mode: TimerMode) {
        timerJob?.cancel()
        val totalSecs = mode.defaultMinutes * 60
        _uiState.update {
            it.copy(
                timerState = it.timerState.copy(
                    mode = mode,
                    isRunning = false,
                    remainingSeconds = totalSecs,
                    totalSeconds = totalSecs,
                    stopwatchSeconds = 0
                )
            )
        }
    }

    fun selectTimerSubject(subjectId: String?, subjectName: String?) {
        _uiState.update {
            it.copy(
                timerState = it.timerState.copy(
                    selectedSubjectId = subjectId,
                    selectedSubjectName = subjectName
                )
            )
        }
    }

    fun selectTimerChapter(chapterId: String?, chapterTitle: String?) {
        _uiState.update {
            it.copy(
                timerState = it.timerState.copy(
                    selectedChapterId = chapterId,
                    selectedChapterTitle = chapterTitle
                )
            )
        }
    }

    fun startTimer() {
        if (_uiState.value.timerState.isRunning) return

        val currentState = _uiState.value.timerState
        timerStartTimestamp = System.currentTimeMillis()
        timerInitialRemainingMs = currentState.remainingSeconds * 1000L

        _uiState.update {
            it.copy(timerState = it.timerState.copy(isRunning = true))
        }

        timerJob = viewModelScope.launch {
            while (true) {
                delay(500)
                val current = _uiState.value.timerState
                if (!current.isRunning) break

                if (current.mode == TimerMode.STOPWATCH) {
                    val elapsedMs = System.currentTimeMillis() - timerStartTimestamp
                    val secs = (elapsedMs / 1000L).toInt()
                    _uiState.update {
                        it.copy(timerState = it.timerState.copy(stopwatchSeconds = secs))
                    }
                } else {
                    val elapsedMs = System.currentTimeMillis() - timerStartTimestamp
                    val remainingMs = maxOf(0L, timerInitialRemainingMs - elapsedMs)
                    val remainingSecs = (remainingMs / 1000L).toInt()

                    _uiState.update {
                        it.copy(timerState = it.timerState.copy(remainingSeconds = remainingSecs))
                    }

                    if (remainingSecs <= 0) {
                        onTimerFinished()
                        break
                    }
                }
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        val current = _uiState.value.timerState
        _uiState.update {
            it.copy(timerState = it.timerState.copy(isRunning = false))
        }
    }

    fun resetTimer() {
        timerJob?.cancel()
        val mode = _uiState.value.timerState.mode
        val totalSecs = mode.defaultMinutes * 60
        _uiState.update {
            it.copy(
                timerState = it.timerState.copy(
                    isRunning = false,
                    remainingSeconds = totalSecs,
                    totalSeconds = totalSecs,
                    stopwatchSeconds = 0
                )
            )
        }
    }

    private fun onTimerFinished() {
        val state = _uiState.value.timerState
        val duration = if (state.mode == TimerMode.STOPWATCH) state.stopwatchSeconds else state.totalSeconds
        val xp = (duration / 60) * 2

        saveStudySession(
            subjectId = state.selectedSubjectId ?: "general",
            subjectName = state.selectedSubjectName ?: "Self Study",
            chapterId = state.selectedChapterId,
            chapterTitle = state.selectedChapterTitle,
            sessionType = state.mode.name.lowercase(),
            durationSeconds = duration.toLong(),
            xpEarned = maxOf(5L, xp.toLong()),
            notes = "Focus session completed"
        )

        _uiState.update {
            it.copy(
                timerState = it.timerState.copy(
                    isRunning = false,
                    completedSessionsCount = it.timerState.completedSessionsCount + 1
                ),
                userMessage = "Focus session complete! Earned $xp XP!"
            )
        }
    }

    fun saveStudySession(
        subjectId: String,
        subjectName: String,
        chapterId: String?,
        chapterTitle: String?,
        sessionType: String,
        durationSeconds: Long,
        xpEarned: Long,
        notes: String?
    ) {
        if (_uiState.value.isGuestMode) {
            val newSession = StudySession(
                id = UUID.randomUUID().toString(),
                userId = "guest",
                subjectId = subjectId,
                subjectName = subjectName,
                chapterId = chapterId,
                chapterTitle = chapterTitle,
                sessionType = sessionType,
                durationSeconds = durationSeconds,
                xpEarned = xpEarned,
                notes = notes,
                completedAt = com.google.firebase.Timestamp.now()
            )
            _uiState.update {
                it.copy(
                    sessions = it.sessions + newSession,
                    userProfile = it.userProfile.copy(
                        totalStudyMinutes = it.userProfile.totalStudyMinutes + (durationSeconds / 60),
                        xp = it.userProfile.xp + xpEarned,
                        level = (it.userProfile.xp + xpEarned) / 100 + 1
                    )
                )
            }
            return
        }

        viewModelScope.launch {
            try {
                repository.logStudySession(
                    subjectId,
                    subjectName,
                    chapterId,
                    chapterTitle,
                    sessionType,
                    durationSeconds,
                    xpEarned,
                    notes
                )
                checkStudyAchievements()
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to save session: ${e.message}") }
            }
        }
    }

    private fun checkStudyAchievements() {
        val totalSessions = _uiState.value.sessions.size + 1
        val totalHours = _uiState.value.userProfile.totalStudyMinutes / 60

        viewModelScope.launch {
            if (totalSessions >= 1) {
                repository.unlockAchievement(
                    "first_session",
                    "First Study Session",
                    "Completed your very first focus study session in StudyPro!"
                )
            }
            if (totalHours >= 10) {
                repository.unlockAchievement(
                    "10_hours",
                    "10 Hours Studied",
                    "Dedicated learner! Completed over 10 hours of focused study."
                )
            }
            if (_uiState.value.userProfile.streakCount >= 7) {
                repository.unlockAchievement(
                    "7_day_streak",
                    "7-Day Streak",
                    "Unstoppable consistency! 7 consecutive days of active study."
                )
            }
        }
    }

    private fun checkChapterAchievements() {
        val completedChapters = _uiState.value.chapters.count { it.isCompleted }
        if (completedChapters >= 50) {
            viewModelScope.launch {
                repository.unlockAchievement(
                    "50_chapters",
                    "50 Chapters Completed",
                    "Mastery unlocked! Completed 50 study chapters."
                )
            }
        }
    }

    // --- ADMIN ACTIONS ---
    fun publishAnnouncement(title: String, message: String, priority: String) {
        viewModelScope.launch {
            try {
                repository.addAnnouncement(title, message, priority)
                _uiState.update { it.copy(userMessage = "Announcement broadcasted successfully!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Broadcast failed: ${e.message}") }
            }
        }
    }

    // --- SUPPORT ---
    fun submitSupport(subject: String, message: String) {
        viewModelScope.launch {
            try {
                repository.submitSupportRequest(subject, message)
                _uiState.update { it.copy(userMessage = "Support request submitted. Our team will review it!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Submission failed: ${e.message}") }
            }
        }
    }

    // --- GOOGLE PAY & UPI PAYMENTS ---
    fun submitPaymentUtr(planId: String, amount: String, utrNumber: String, onSuccess: () -> Unit) {
        if (_uiState.value.isGuestMode) {
            _uiState.update { it.copy(userMessage = "Please sign in with Google to purchase StudyPro Pro.") }
            return
        }
        viewModelScope.launch {
            try {
                repository.submitPayment(planId, amount, utrNumber)
                _uiState.update { it.copy(userMessage = "Payment submitted! Admin will verify UTR and activate your Pro plan shortly.") }
                onSuccess()
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to submit payment: ${e.message}") }
            }
        }
    }

    fun updatePaymentConfig(upiId: String, payeeName: String, monthlyPrice: String, yearlyPrice: String, instructions: String) {
        viewModelScope.launch {
            try {
                val config = AppPaymentConfig(
                    upiId = upiId.trim(),
                    payeeName = payeeName.trim(),
                    monthlyPrice = monthlyPrice.trim(),
                    yearlyPrice = yearlyPrice.trim(),
                    instructions = instructions.trim()
                )
                repository.savePaymentConfig(config)
                _uiState.update { it.copy(userMessage = "Google Pay UPI settings saved successfully!") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to update UPI settings: ${e.message}") }
            }
        }
    }

    fun approvePayment(payment: PaymentRecord) {
        viewModelScope.launch {
            try {
                repository.approvePayment(payment)
                _uiState.update { it.copy(userMessage = "Payment approved! Activated StudyPro Pro for ${payment.userEmail}.") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Approval failed: ${e.message}") }
            }
        }
    }

    fun rejectPayment(paymentId: String) {
        viewModelScope.launch {
            try {
                repository.rejectPayment(paymentId)
                _uiState.update { it.copy(userMessage = "Payment request marked as rejected.") }
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Reject failed: ${e.message}") }
            }
        }
    }

    // --- ACCOUNT DELETION ---
    fun deleteAccount(onSuccess: () -> Unit) {
        if (_uiState.value.isGuestMode) {
            _uiState.update {
                it.copy(
                    subjects = emptyList(),
                    chapters = emptyList(),
                    goals = emptyList(),
                    sessions = emptyList(),
                    userMessage = "Guest data cleared."
                )
            }
            onSuccess()
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteUserAccount()
                _uiState.update { it.copy(userMessage = "Account data completely deleted.") }
                onSuccess()
            } catch (e: Exception) {
                _uiState.update { it.copy(userMessage = "Failed to delete account: ${e.message}") }
            }
        }
    }
}
