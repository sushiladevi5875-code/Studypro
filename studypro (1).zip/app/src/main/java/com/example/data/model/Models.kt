package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val classGrade: String = "",
    val school: String? = null,
    val dailyStudyTargetMinutes: Long = 120L,
    val streakCount: Long = 0L,
    val totalStudyMinutes: Long = 0L,
    val xp: Long = 0L,
    val level: Long = 1L,
    val isPremium: Boolean = false,
    val subscriptionPlan: String = "free",
    val subscriptionExpiry: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Subject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val colorHex: String = "#2563EB",
    val targetHours: Long = 40L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Chapter(
    @DocumentId val id: String = "",
    val userId: String = "",
    val subjectId: String = "",
    val title: String = "",
    val orderIndex: Long = 0L,
    val isCompleted: Boolean = false,
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StudyGoal(
    @DocumentId val id: String = "",
    val userId: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterId: String? = null,
    val chapterTitle: String? = null,
    val targetDate: String = "",
    val targetTime: String? = null,
    val durationMinutes: Long = 45L,
    val notes: String? = null,
    val priority: String = "medium", // "low", "medium", "high"
    val isCompleted: Boolean = false,
    val completedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StudySession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val chapterId: String? = null,
    val chapterTitle: String? = null,
    val sessionType: String = "pomodoro", // "pomodoro", "short_break", "long_break", "stopwatch"
    val durationSeconds: Long = 1500L,
    val xpEarned: Long = 25L,
    val notes: String? = null,
    val completedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Achievement(
    @DocumentId val id: String = "",
    val userId: String = "",
    val badgeKey: String = "",
    val title: String = "",
    val description: String = "",
    val unlockedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Announcement(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val priority: String = "normal",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SupportRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val subject: String = "",
    val message: String = "",
    val status: String = "open",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PaymentRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val planId: String = "pro_yearly",
    val amount: String = "₹399",
    val utrNumber: String = "",
    val status: String = "pending", // "pending", "approved", "rejected"
    val reviewedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AppPaymentConfig(
    @DocumentId val id: String = "payment",
    val upiId: String = "sushiladevi5875-5@okicici",
    val payeeName: String = "StudyPro Education",
    val monthlyPrice: String = "₹49",
    val yearlyPrice: String = "₹399",
    val instructions: String = "Pay directly via Google Pay / PhonePe / Paytm / BHIM UPI to our verified account."
)

