package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Achievement
import com.example.data.model.Announcement
import com.example.data.model.AppPaymentConfig
import com.example.data.model.Chapter
import com.example.data.model.PaymentRecord
import com.example.data.model.StudyGoal
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.data.model.SupportRequest
import com.example.data.model.UserProfile
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudyProRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before performing database operations.")
    }

    // --- USER PROFILE ---
    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) snapshot.toObject(UserProfile::class.java) else null
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveUserProfile(profile: UserProfile) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "name" to profile.name,
            "classGrade" to profile.classGrade,
            "dailyStudyTargetMinutes" to profile.dailyStudyTargetMinutes,
            "streakCount" to profile.streakCount,
            "totalStudyMinutes" to profile.totalStudyMinutes,
            "xp" to profile.xp,
            "level" to profile.level,
            "isPremium" to profile.isPremium,
            "subscriptionPlan" to profile.subscriptionPlan,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!profile.school.isNullOrBlank()) {
            payload["school"] = profile.school
        }
        if (profile.subscriptionExpiry != null) {
            payload["subscriptionExpiry"] = profile.subscriptionExpiry
        }

        try {
            val existing = docRef.get().await()
            if (!existing.exists()) {
                payload["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(payload).await()
            } else {
                docRef.update(payload).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    // --- SUBJECTS ---
    fun observeSubjects(userId: String): Flow<List<Subject>> = flow {
        val path = "users/$userId/subjects"
        emitAll(
            db.collection("users").document(userId).collection("subjects")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Subject::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addSubject(name: String, colorHex: String, targetHours: Long = 40L): String {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("subjects").document()
        val payload = mapOf(
            "userId" to uid,
            "name" to name.trim(),
            "colorHex" to colorHex,
            "targetHours" to targetHours,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateSubject(subject: Subject) {
        val uid = requireUserId()
        require(subject.id.isNotBlank()) { "Subject ID must not be blank" }
        val docRef = db.collection("users").document(uid).collection("subjects").document(subject.id)
        val payload = mapOf(
            "name" to subject.name.trim(),
            "colorHex" to subject.colorHex,
            "targetHours" to subject.targetHours,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.update(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteSubject(subjectId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("subjects").document(subjectId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- CHAPTERS ---
    fun observeChapters(userId: String): Flow<List<Chapter>> = flow {
        val path = "users/$userId/chapters"
        emitAll(
            db.collection("users").document(userId).collection("chapters")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Chapter::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addChapter(subjectId: String, title: String, orderIndex: Long = 0L, notes: String? = null): String {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("chapters").document()
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "subjectId" to subjectId,
            "title" to title.trim(),
            "orderIndex" to orderIndex,
            "isCompleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!notes.isNullOrBlank()) {
            payload["notes"] = notes.trim()
        }
        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun toggleChapterCompletion(chapter: Chapter) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("chapters").document(chapter.id)
        val payload = mapOf(
            "isCompleted" to !chapter.isCompleted,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.update(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteChapter(chapterId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("chapters").document(chapterId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- STUDY GOALS / PLANNER ---
    fun observeGoals(userId: String): Flow<List<StudyGoal>> = flow {
        val path = "users/$userId/goals"
        emitAll(
            db.collection("users").document(userId).collection("goals")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(StudyGoal::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addGoal(
        subjectId: String,
        subjectName: String,
        chapterId: String?,
        chapterTitle: String?,
        targetDate: String,
        targetTime: String?,
        durationMinutes: Long,
        priority: String,
        notes: String?
    ): String {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("goals").document()
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "subjectId" to subjectId,
            "subjectName" to subjectName,
            "targetDate" to targetDate,
            "durationMinutes" to durationMinutes,
            "priority" to priority,
            "isCompleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!chapterId.isNullOrBlank()) payload["chapterId"] = chapterId
        if (!chapterTitle.isNullOrBlank()) payload["chapterTitle"] = chapterTitle
        if (!targetTime.isNullOrBlank()) payload["targetTime"] = targetTime
        if (!notes.isNullOrBlank()) payload["notes"] = notes
        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun toggleGoalCompletion(goal: StudyGoal) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("goals").document(goal.id)
        val newStatus = !goal.isCompleted
        val payload = mutableMapOf<String, Any>(
            "isCompleted" to newStatus,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (newStatus) {
            payload["completedAt"] = FieldValue.serverTimestamp()
        }
        try {
            docRef.update(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteGoal(goalId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("goals").document(goalId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- STUDY SESSIONS ---
    fun observeSessions(userId: String): Flow<List<StudySession>> = flow {
        val path = "users/$userId/sessions"
        emitAll(
            db.collection("users").document(userId).collection("sessions")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(StudySession::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun logStudySession(
        subjectId: String,
        subjectName: String,
        chapterId: String?,
        chapterTitle: String?,
        sessionType: String,
        durationSeconds: Long,
        xpEarned: Long,
        notes: String?
    ): String {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("sessions").document()
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "subjectId" to subjectId,
            "subjectName" to subjectName,
            "sessionType" to sessionType,
            "durationSeconds" to durationSeconds,
            "xpEarned" to xpEarned,
            "completedAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!chapterId.isNullOrBlank()) payload["chapterId"] = chapterId
        if (!chapterTitle.isNullOrBlank()) payload["chapterTitle"] = chapterTitle
        if (!notes.isNullOrBlank()) payload["notes"] = notes

        try {
            docRef.set(payload).await()

            // Update user profile total minutes, xp, and streak
            val profileRef = db.collection("users").document(uid)
            val profileDoc = profileRef.get().await()
            if (profileDoc.exists()) {
                val currentMins = profileDoc.getLong("totalStudyMinutes") ?: 0L
                val currentXp = profileDoc.getLong("xp") ?: 0L
                val newMins = currentMins + (durationSeconds / 60)
                val newXp = currentXp + xpEarned
                val newLevel = (newXp / 100) + 1
                profileRef.update(
                    mapOf(
                        "totalStudyMinutes" to newMins,
                        "xp" to newXp,
                        "level" to newLevel,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // --- ACHIEVEMENTS ---
    fun observeAchievements(userId: String): Flow<List<Achievement>> = flow {
        val path = "users/$userId/achievements"
        emitAll(
            db.collection("users").document(userId).collection("achievements")
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Achievement::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun unlockAchievement(badgeKey: String, title: String, description: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("achievements").document(badgeKey)
        val existing = docRef.get().await()
        if (existing.exists()) return

        val payload = mapOf(
            "userId" to uid,
            "badgeKey" to badgeKey,
            "title" to title,
            "description" to description,
            "unlockedAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // --- ANNOUNCEMENTS ---
    fun observeAnnouncements(): Flow<List<Announcement>> = flow {
        val path = "announcements"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(Announcement::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addAnnouncement(title: String, message: String, priority: String) {
        val docRef = db.collection("announcements").document()
        val payload = mapOf(
            "title" to title.trim(),
            "message" to message.trim(),
            "priority" to priority,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // --- SUPPORT / FEEDBACK ---
    suspend fun submitSupportRequest(subject: String, message: String) {
        val uid = requireUserId()
        val userEmail = auth.currentUser?.email ?: "unknown@student.com"
        val docRef = db.collection("support_requests").document()
        val payload = mapOf(
            "userId" to uid,
            "userEmail" to userEmail,
            "subject" to subject.trim(),
            "message" to message.trim(),
            "status" to "open",
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    fun observeSupportRequests(): Flow<List<SupportRequest>> = flow {
        val uid = requireUserId()
        val path = "support_requests"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(SupportRequest::class.java).filter { it.userId == uid }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    // --- GOOGLE PAY / UPI CONFIGURATION & VERIFICATION ---
    fun observePaymentConfig(): Flow<AppPaymentConfig> = flow {
        val path = "app_config/payment"
        emitAll(
            db.collection("app_config").document("payment")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(AppPaymentConfig::class.java) ?: AppPaymentConfig()
                    } else {
                        AppPaymentConfig()
                    }
                }
                .catch { error ->
                    emit(AppPaymentConfig())
                }
        )
    }

    suspend fun savePaymentConfig(config: AppPaymentConfig) {
        val docRef = db.collection("app_config").document("payment")
        val payload = mapOf(
            "upiId" to config.upiId.trim(),
            "payeeName" to config.payeeName.trim(),
            "monthlyPrice" to config.monthlyPrice.trim(),
            "yearlyPrice" to config.yearlyPrice.trim(),
            "instructions" to config.instructions.trim()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun submitPayment(planId: String, amount: String, utrNumber: String): String {
        val uid = requireUserId()
        val userEmail = auth.currentUser?.email ?: "student@studypro.app"
        val docRef = db.collection("payments").document()
        val payload = mapOf(
            "userId" to uid,
            "userEmail" to userEmail,
            "planId" to planId,
            "amount" to amount,
            "utrNumber" to utrNumber.trim(),
            "status" to "pending",
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    fun observePayments(): Flow<List<PaymentRecord>> = flow {
        val path = "payments"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot -> snapshot.toObjects(PaymentRecord::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun approvePayment(payment: PaymentRecord) {
        val paymentRef = db.collection("payments").document(payment.id)
        val userRef = db.collection("users").document(payment.userId)

        try {
            // Update payment record to approved
            paymentRef.update(
                mapOf(
                    "status" to "approved",
                    "reviewedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // Calculate expiry (1 month or 1 year)
            val cal = java.util.Calendar.getInstance()
            if (payment.planId == "pro_monthly") {
                cal.add(java.util.Calendar.MONTH, 1)
            } else {
                cal.add(java.util.Calendar.YEAR, 1)
            }
            val expiryTimestamp = Timestamp(cal.time)

            userRef.update(
                mapOf(
                    "isPremium" to true,
                    "subscriptionPlan" to payment.planId,
                    "subscriptionExpiry" to expiryTimestamp,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, paymentRef.path)
            throw e
        }
    }

    suspend fun rejectPayment(paymentId: String) {
        val paymentRef = db.collection("payments").document(paymentId)
        try {
            paymentRef.update(
                mapOf(
                    "status" to "rejected",
                    "reviewedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, paymentRef.path)
            throw e
        }
    }

    // --- ACCOUNT DELETION ---
    suspend fun deleteUserAccount() {
        val uid = requireUserId()
        try {
            // Delete subcollections documents
            val subjects = db.collection("users").document(uid).collection("subjects").get().await()
            for (doc in subjects.documents) {
                doc.reference.delete().await()
            }
            val chapters = db.collection("users").document(uid).collection("chapters").get().await()
            for (doc in chapters.documents) {
                doc.reference.delete().await()
            }
            val goals = db.collection("users").document(uid).collection("goals").get().await()
            for (doc in goals.documents) {
                doc.reference.delete().await()
            }
            val sessions = db.collection("users").document(uid).collection("sessions").get().await()
            for (doc in sessions.documents) {
                doc.reference.delete().await()
            }
            val achievements = db.collection("users").document(uid).collection("achievements").get().await()
            for (doc in achievements.documents) {
                doc.reference.delete().await()
            }
            db.collection("users").document(uid).delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$uid")
            throw e
        }
    }
}
