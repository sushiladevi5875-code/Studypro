package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.StudyProViewModel
import com.example.ui.admin.AdminScreen
import com.example.ui.analytics.AnalyticsScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.components.StudyProBottomBar
import com.example.ui.components.StudyProTopBar
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.gamification.GamificationScreen
import com.example.ui.planner.PlannerScreen
import com.example.ui.premium.PremiumScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.subjects.SubjectsScreen
import com.example.ui.theme.StudyProTheme
import com.example.ui.timer.TimerScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            StudyProApp()
        }
    }
}

@Composable
fun StudyProApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var isGuestMode by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    if (currentUser == null && !isGuestMode) {
        StudyProTheme(darkTheme = true) {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                    isGuestMode = false
                },
                onContinueAsGuest = {
                    isGuestMode = true
                }
            )
        }
    } else {
        val currentUserId = currentUser?.uid ?: "guest"
        key(currentUserId) {
            val viewModel: StudyProViewModel = viewModel()

            LaunchedEffect(isGuestMode) {
                if (isGuestMode) {
                    viewModel.setGuestMode(true)
                }
            }

            val uiState by viewModel.uiState.collectAsState()

            LaunchedEffect(uiState.userMessage) {
                uiState.userMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearUserMessage()
                }
            }

            // Handle back navigation for sub-screens
            if (uiState.currentScreen != AppScreen.DASHBOARD) {
                BackHandler {
                    viewModel.navigateTo(AppScreen.DASHBOARD)
                }
            }

            StudyProTheme(darkTheme = uiState.isDarkTheme) {
                Scaffold(
                    topBar = {
                        StudyProTopBar(
                            uiState = uiState,
                            onNavigate = { screen -> viewModel.navigateTo(screen) }
                        )
                    },
                    bottomBar = {
                        // Only show bottom navigation for primary tabs
                        if (uiState.currentScreen in listOf(
                                AppScreen.DASHBOARD,
                                AppScreen.SUBJECTS,
                                AppScreen.PLANNER,
                                AppScreen.TIMER,
                                AppScreen.ANALYTICS
                            )
                        ) {
                            StudyProBottomBar(
                                currentScreen = uiState.currentScreen,
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentScreen) {
                            AppScreen.DASHBOARD -> DashboardScreen(
                                uiState = uiState,
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                            AppScreen.SUBJECTS -> SubjectsScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            AppScreen.PLANNER -> PlannerScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            AppScreen.TIMER -> TimerScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            AppScreen.ANALYTICS -> AnalyticsScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                            AppScreen.GAMIFICATION -> GamificationScreen(
                                uiState = uiState
                            )
                            AppScreen.PREMIUM -> PremiumScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            AppScreen.ADMIN -> AdminScreen(
                                uiState = uiState,
                                viewModel = viewModel
                            )
                            AppScreen.SETTINGS -> SettingsScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                onSignOut = {
                                    if (isGuestMode) {
                                        isGuestMode = false
                                        currentUser = null
                                    } else {
                                        signOut(credentialManager, coroutineScope) {
                                            currentUser = null
                                            isGuestMode = false
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
