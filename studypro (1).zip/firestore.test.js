const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_student_123";
const BOB_UID = "bob_student_456";
const ADMIN_UID = "admin_owner_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// --- TESTS ---

test("Unauthenticated user: cannot read user profiles or subcollections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("subjects").get());
});

test("Authenticated user: can create and read their own profile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice Smith",
      classGrade: "Grade 11",
      school: "Lincoln High",
      dailyStudyTargetMinutes: 180,
      streakCount: 1,
      totalStudyMinutes: 60,
      xp: 150,
      level: 1,
      isPremium: false,
      subscriptionPlan: "free",
      createdAt: now,
      updatedAt: now,
    })
  );

  const doc = await aliceDb.collection("users").doc(ALICE_UID).get();
  await assertSucceeds(Promise.resolve(doc));
});

test("Cross-user access: Bob cannot read Alice's profile or subjects", async () => {
  // Seed Alice data using admin
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const now = new Date();
    await context.firestore().collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice Smith",
      classGrade: "Grade 11",
      dailyStudyTargetMinutes: 120,
      streakCount: 0,
      totalStudyMinutes: 0,
      xp: 0,
      level: 1,
      isPremium: false,
      subscriptionPlan: "free",
      createdAt: now,
      updatedAt: now,
    });
    await context.firestore().collection("users").doc(ALICE_UID).collection("subjects").doc("math").set({
      userId: ALICE_UID,
      name: "Mathematics",
      colorHex: "#2563EB",
      targetHours: 50,
      createdAt: now,
      updatedAt: now,
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("subjects").doc("math").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("subjects").get());
});

test("Authenticated user: can create and manage their own subjects and chapters", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("subjects").doc("physics").set({
      userId: ALICE_UID,
      name: "Physics",
      colorHex: "#7C3AED",
      targetHours: 40,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chapters").doc("ch1").set({
      userId: ALICE_UID,
      subjectId: "physics",
      title: "Newtonian Mechanics",
      orderIndex: 0,
      isCompleted: false,
      notes: "Three laws of motion",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Admin check: verified admin can manage announcements", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "sushiladevi5875@gmail.com",
    email_verified: true,
  }).firestore();
  const now = new Date();

  await assertSucceeds(
    adminDb.collection("announcements").doc("ann1").set({
      title: "Welcome to StudyPro",
      message: "Start tracking your study targets today!",
      priority: "high",
      createdAt: now,
    })
  );

  const studentDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  // Student can read announcements
  await assertSucceeds(studentDb.collection("announcements").doc("ann1").get());
  // Student CANNOT create announcements
  await assertFails(
    studentDb.collection("announcements").doc("ann2").set({
      title: "Fake",
      message: "Hacked",
      priority: "urgent",
      createdAt: now,
    })
  );
});
